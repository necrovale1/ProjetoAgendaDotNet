﻿namespace ProjetoAgendaDotNet.Dados
{


    partial class DataSetPessoa
    {
        partial class DSPessoaDataTable
        {
        }
    }
}

namespace ProjetoAgendaDotNet.Dados.DataSetPessoaTableAdapters
{


    public partial class DSPessoaTableAdapter
    {
    }
}
